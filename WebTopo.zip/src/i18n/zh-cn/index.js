export default {
    failed: '操作失败',
    success: '操作成功'
}