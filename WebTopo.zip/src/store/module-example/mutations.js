/*
export function someMutation (state) {
}
*/
